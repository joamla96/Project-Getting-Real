﻿using System;
using Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Core.CustomExceptions;

namespace Tests.Core {
	[TestClass]
	class Utils {
		[TestMethod]
		public void populateTables() {

		}
	}
}
