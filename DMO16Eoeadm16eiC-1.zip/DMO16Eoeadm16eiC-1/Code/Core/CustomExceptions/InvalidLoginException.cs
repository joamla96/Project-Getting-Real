﻿using System;

namespace Core.CustomExceptions {
	public class InvalidLoginException : Exception {
		public InvalidLoginException() { }
	}
}
