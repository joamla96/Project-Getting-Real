﻿using System;

namespace Core.CustomExceptions {
	public class NoUserException : Exception {
		public NoUserException() {}
	}
}
